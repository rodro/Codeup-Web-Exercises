(function(){
    "use strict";


var names = ['rick', 'morty', 'beth', 'jerry'];

    // TODO: Create an array of 4 people's names using literal array notation, in a variable called 'names'.

console.log(names.length);
    // TODO: Create a log statement that will log the number of elements in the names array.
 for (var i = 0; i < names.length; i++){
 	console.log (names[i]);
 }

names.forEach(function(names){
	console.log (names);
	

	
});



})()



    // TODO: Create log statements that will print each of the names array elements individually.






// var text;
// var adlib = prompt("compelete this sentence");("what is")


// switch(favDrink) {
//     case "Martini":
//         text = "Excellent choice! Martini is good for your soul.";
//         break;
//     case "Daiquiri":
//         text = "Daiquiri is my favorite too!";
//         break;
//     case "Cosmopolitan":
//         text = "Really? Are you sure the Cosmopolitan is your favorite?";
//         break;
//     default:
//         text = "I have never heard of that one..";
//         break;
// }
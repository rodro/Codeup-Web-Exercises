"use strict";

// ... code

// myAge = 25;
alert("Message goes here.");
prompt('Please type something:')
// .. rest of code
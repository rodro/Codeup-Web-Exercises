var usernum = prompt("pick a number betwent 1-10")

for (var i = 0; i <= 100; i++) {
	console.log(i+"x"+ usernum + "=" + (usernum*i))
}
